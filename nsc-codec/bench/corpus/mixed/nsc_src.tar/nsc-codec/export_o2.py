"""Export the FastO2 order-2 table as a dependency-free binary (o2.nsc) for the Rust feature
model (src/features.rs). Uses the SAME `Artifacts(...).o2` that generated ref.nsc's features, so
the Rust order-2 lookup matches Python bit-for-bit.

o2.nsc layout:
  magic 'NO21' (4 bytes)
  V u32, K u32 (order2_match_order), cap f32 (match_len_cap), n u32
  ctx  (n x i64, strictly ascending a*V+b context keys)
  top  (n x i32, most-likely next token)
  conf (n x f32, confidence = count(top)/total)
"""
import os, sys, struct
import numpy as np

ROOT = "/home/christian/Escritorio/compression-algorithms/Syntropy2"
os.chdir(ROOT); sys.path.insert(0, ROOT)
import torch; torch.set_grad_enabled(False)
from test_compression_integrity import Artifacts

art = Artifacts("results/export", "data/enwik8", quiet=True)
cfg, o2 = art.cfg, art.o2
os.makedirs("nsc-codec/artifacts", exist_ok=True)

ctx = np.ascontiguousarray(o2.ctx, dtype="<i8")
top = np.ascontiguousarray(o2.top, dtype="<i4")
conf = np.ascontiguousarray(o2.conf, dtype="<f4")
assert ctx.shape == top.shape == conf.shape, "o2 arrays misaligned"
assert ctx.ndim == 1 and len(ctx) > 0, "empty o2 table"
assert np.all(ctx[1:] > ctx[:-1]), "ctx must be strictly ascending (binary search precondition)"
assert int(np.asarray(o2.top).max()) < cfg.vocab_size, "top token id out of range"
n = len(ctx)

path = "nsc-codec/artifacts/o2.nsc"
with open(path, "wb") as f:
    f.write(b"NO21")
    f.write(struct.pack("<IIfI", int(cfg.vocab_size), int(cfg.order2_match_order),
                        float(cfg.match_len_cap), n))
    f.write(ctx.tobytes()); f.write(top.tobytes()); f.write(conf.tobytes())
print(f"wrote {path}: {n:,} order-2 contexts, {os.path.getsize(path) / 1e6:.1f} MB "
      f"(V={cfg.vocab_size}, K={cfg.order2_match_order}, cap={cfg.match_len_cap})")
