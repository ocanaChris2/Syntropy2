//! `nsc studio` — a local control panel for the codec, served as a tiny web app.
//!
//! Dependency-free, std-only: a `TcpListener` HTTP/1.1 server (thread per connection) exposes a
//! small JSON API and serves an embedded single-page dashboard. It lets you compress/decompress
//! real local files, watch live metrics (ratio, bits-per-byte, speed), verify losslessness, race
//! the codec against classical compressors (gzip/xz/zstd/7z-PPMd), deploy model upgrades through
//! the versioned registry, and track behaviour over time via a persisted run history.
//!
//! The heavy lifting reuses the same binary: model management reads the [`Registry`] directly, and
//! compress/decompress/info shell out to this very executable's CLI subcommands (so tokenization,
//! the fingerprint container, and every codec path are byte-for-byte the ones the CLI uses).
use crate::bench::{bench_7z, bench_pipe, detect_classical, files_equal};
use crate::registry::Registry;
use std::collections::HashMap;
use std::fs;
use std::io::{BufRead, BufReader, Read, Write};
use std::net::{TcpListener, TcpStream};
use std::path::{Path, PathBuf};
use std::process::Command;
use std::sync::atomic::{AtomicU64, Ordering};
use std::sync::{Arc, Mutex};
use std::time::Instant;

const INDEX_HTML: &str = include_str!("studio.html");
static SEQ: AtomicU64 = AtomicU64::new(0);

struct Ctx {
    self_exe: PathBuf,
    home: PathBuf,
    browse_root: PathBuf,
    classical: Vec<String>,
    hist_path: PathBuf,
    hist_lock: Mutex<()>,
    quiet: bool,
}

pub fn run(reg: Registry, cli: &crate::Cli) -> Result<(), String> {
    let port: u16 = cli.get("port").and_then(|s| s.parse().ok()).unwrap_or(8765);
    let self_exe = std::env::current_exe().map_err(|e| format!("current_exe: {e}"))?;
    let home = reg.home().to_path_buf();
    let classical = detect_classical();
    // Where the file browser opens by default: --root if given, else the launch dir. This makes the
    // Browse buttons surface the files you're actually working with (e.g. results/) instead of $HOME.
    let browse_root = match cli.get("root") {
        Some(r) => expand_home(r),
        None => std::env::current_dir().unwrap_or_else(|_| home.clone()),
    };
    let browse_root = fs::canonicalize(&browse_root).unwrap_or(browse_root);
    let ctx = Arc::new(Ctx {
        self_exe,
        home: home.clone(),
        browse_root,
        classical: classical.clone(),
        hist_path: home.join("studio_history.json"),
        hist_lock: Mutex::new(()),
        quiet: cli.quiet(),
    });

    let addr = format!("127.0.0.1:{port}");
    let listener = TcpListener::bind(&addr).map_err(|e| format!("bind {addr}: {e}"))?;
    let url = format!("http://{addr}");
    println!("Syntropy2 Studio  ->  {url}");
    println!("  nsc binary : {}", ctx.self_exe.display());
    println!("  registry   : {}", ctx.home.display());
    println!("  browse root: {}", ctx.browse_root.display());
    println!("  classical  : {}", if classical.is_empty() { "none detected".into() } else { classical.join(", ") });
    println!("  Ctrl-C to stop.");
    // best-effort: open the browser
    let _ = Command::new("xdg-open").arg(&url).stdout(std::process::Stdio::null())
        .stderr(std::process::Stdio::null()).spawn();

    for stream in listener.incoming() {
        match stream {
            Ok(s) => {
                let ctx = Arc::clone(&ctx);
                std::thread::spawn(move || { let _ = serve(&ctx, s); });
            }
            Err(_) => continue,
        }
    }
    Ok(())
}

// ---------------------------------------------------------------- HTTP plumbing
struct Req {
    method: String,
    path: String,
    query: String,
    body: String,
}

fn read_request(stream: &TcpStream) -> Option<Req> {
    let mut reader = BufReader::new(stream);
    let mut line = String::new();
    if reader.read_line(&mut line).ok()? == 0 { return None; }
    let mut it = line.split_whitespace();
    let method = it.next()?.to_string();
    let target = it.next()?.to_string();
    let (path, query) = match target.split_once('?') {
        Some((p, q)) => (p.to_string(), q.to_string()),
        None => (target, String::new()),
    };
    let mut content_len = 0usize;
    loop {
        let mut h = String::new();
        if reader.read_line(&mut h).ok()? == 0 { break; }
        let t = h.trim_end();
        if t.is_empty() { break; }
        if let Some((k, v)) = t.split_once(':') {
            if k.trim().eq_ignore_ascii_case("content-length") {
                content_len = v.trim().parse().unwrap_or(0);
            }
        }
    }
    let mut body = vec![0u8; content_len];
    if content_len > 0 { reader.read_exact(&mut body).ok()?; }
    Some(Req { method, path, query, body: String::from_utf8_lossy(&body).into_owned() })
}

fn respond(stream: &mut TcpStream, code: u16, ctype: &str, body: &[u8]) {
    let status = match code { 200 => "OK", 404 => "Not Found", 500 => "Internal Server Error", _ => "OK" };
    let head = format!(
        "HTTP/1.1 {code} {status}\r\nContent-Type: {ctype}\r\nContent-Length: {}\r\nConnection: close\r\n\r\n",
        body.len());
    let _ = stream.write_all(head.as_bytes());
    let _ = stream.write_all(body);
    let _ = stream.flush();
}

fn json(stream: &mut TcpStream, code: u16, body: &str) {
    respond(stream, code, "application/json", body.as_bytes());
}

fn serve(ctx: &Ctx, mut stream: TcpStream) -> std::io::Result<()> {
    let req = match read_request(&stream) { Some(r) => r, None => return Ok(()) };
    match (req.method.as_str(), req.path.as_str()) {
        ("GET", "/") | ("GET", "/index.html") => respond(&mut stream, 200, "text/html; charset=utf-8", INDEX_HTML.as_bytes()),
        ("GET", "/api/status") => json(&mut stream, 200, &api_status(ctx)),
        ("GET", "/api/models") => json(&mut stream, 200, &api_models(ctx)),
        ("GET", "/api/history") => json(&mut stream, 200, &read_history(ctx)),
        ("GET", "/api/browse") => json(&mut stream, 200, &api_browse(&query_get(&req.query, "path"), &ctx.browse_root)),
        ("POST", "/api/compress") => stream_compress(ctx, &req.body, &mut stream),
        ("POST", "/api/decompress") => json(&mut stream, 200, &api_decompress(ctx, &req.body)),
        ("POST", "/api/models/add") => json(&mut stream, 200, &api_model_add(ctx, &req.body)),
        ("POST", "/api/models/default") => json(&mut stream, 200, &api_model_default(ctx, &req.body)),
        ("POST", "/api/models/remove") => json(&mut stream, 200, &api_model_remove(ctx, &req.body)),
        ("POST", "/api/history/clear") => { let _ = fs::remove_file(&ctx.hist_path); json(&mut stream, 200, "{\"ok\":true}"); }
        _ => json(&mut stream, 404, "{\"error\":\"not found\"}"),
    }
    Ok(())
}

// ---------------------------------------------------------------- JSON helpers
fn esc(s: &str) -> String {
    let mut o = String::with_capacity(s.len() + 2);
    for c in s.chars() {
        match c {
            '"' => o.push_str("\\\""),
            '\\' => o.push_str("\\\\"),
            '\n' => o.push_str("\\n"),
            '\r' => o.push_str("\\r"),
            '\t' => o.push_str("\\t"),
            c if (c as u32) < 0x20 => o.push_str(&format!("\\u{:04x}", c as u32)),
            c => o.push(c),
        }
    }
    o
}
fn qs(s: &str) -> String { format!("\"{}\"", esc(s)) }

/// Parse a flat JSON object body into key -> string value (bools/numbers kept as their literal).
fn parse_body(s: &str) -> HashMap<String, String> {
    let mut m = HashMap::new();
    let c: Vec<char> = s.chars().collect();
    let mut i = 0usize;
    let read_str = |c: &[char], i: &mut usize| -> String {
        let mut out = String::new();
        while *i < c.len() && c[*i] != '"' {
            if c[*i] == '\\' && *i + 1 < c.len() {
                *i += 1;
                out.push(match c[*i] { 'n' => '\n', 't' => '\t', 'r' => '\r', other => other });
            } else { out.push(c[*i]); }
            *i += 1;
        }
        *i += 1;
        out
    };
    while i < c.len() {
        if c[i] == '"' {
            i += 1;
            let key = read_str(&c, &mut i);
            while i < c.len() && c[i] != ':' { i += 1; }
            i += 1;
            while i < c.len() && c[i].is_whitespace() { i += 1; }
            if i >= c.len() { break; }
            let val = if c[i] == '"' { i += 1; read_str(&c, &mut i) } else {
                let mut out = String::new();
                while i < c.len() && c[i] != ',' && c[i] != '}' { out.push(c[i]); i += 1; }
                out.trim().to_string()
            };
            m.insert(key, val);
        } else { i += 1; }
    }
    m
}
fn field<'a>(m: &'a HashMap<String, String>, k: &str) -> &'a str { m.get(k).map(|s| s.as_str()).unwrap_or("") }
fn flag(m: &HashMap<String, String>, k: &str) -> bool { m.get(k).map(|s| s == "true").unwrap_or(false) }

// ---------------------------------------------------------------- status / models
fn open_reg(ctx: &Ctx) -> Registry { Registry::with_home(ctx.home.clone()) }

fn models_json(ctx: &Ctx) -> String {
    let reg = open_reg(ctx);
    let def = reg.default_id();
    let mut out = String::from("[");
    if let Ok(models) = reg.list() {
        for (i, m) in models.iter().enumerate() {
            let man = &m.manifest;
            let disk: u64 = ["model.nsc", "o2.nsc", "tokenizer.json"].iter()
                .filter_map(|f| fs::metadata(m.dir.join(f)).ok().map(|md| md.len())).sum();
            let is_def = def.as_deref() == Some(&man.id);
            if i > 0 { out.push(','); }
            out.push_str(&format!(
                "{{\"id\":{},\"is_default\":{},\"tier\":{},\"vocab_size\":{},\"seg_len\":{},\"d_model\":{},\"bpc\":{},\"created\":{},\"fingerprint\":{},\"notes\":{},\"disk_bytes\":{}}}",
                qs(&man.id), is_def, qs(&man.tier), man.vocab_size, man.seg_len, man.d_model,
                man.bpc, qs(&man.created), man.fingerprint, qs(&man.notes), disk));
        }
    }
    out.push(']');
    out
}

fn api_models(ctx: &Ctx) -> String {
    let reg = open_reg(ctx);
    format!("{{\"registry\":{},\"default\":{},\"models\":{}}}",
        qs(&ctx.home.display().to_string()),
        reg.default_id().map(|d| qs(&d)).unwrap_or_else(|| "null".into()),
        models_json(ctx))
}

fn api_status(ctx: &Ctx) -> String {
    let ver = run_capture(&ctx.self_exe, &["version".into()]).map(|(o, _, _)| o.trim().to_string());
    let classical = ctx.classical.iter().map(|c| qs(c)).collect::<Vec<_>>().join(",");
    let reg = open_reg(ctx);
    format!("{{\"nsc\":{},\"nsc_version\":{},\"home\":{},\"classical\":[{}],\"registry\":{},\"default\":{},\"models\":{}}}",
        qs(&ctx.self_exe.display().to_string()),
        ver.map(|v| qs(&v)).unwrap_or_else(|| "null".into()),
        qs(&ctx.home.display().to_string()), classical,
        qs(&ctx.home.display().to_string()),
        reg.default_id().map(|d| qs(&d)).unwrap_or_else(|| "null".into()),
        models_json(ctx))
}

// ---------------------------------------------------------------- process helpers
fn run_capture(exe: &Path, args: &[String]) -> Option<(String, String, bool)> {
    let out = Command::new(exe).args(args).output().ok()?;
    Some((String::from_utf8_lossy(&out.stdout).into_owned(),
          String::from_utf8_lossy(&out.stderr).into_owned(),
          out.status.success()))
}

fn nsc(ctx: &Ctx, args: &[&str]) -> Option<(String, String, bool)> {
    let mut a: Vec<String> = args.iter().map(|s| s.to_string()).collect();
    a.push("--home".into());
    a.push(ctx.home.display().to_string());
    run_capture(&ctx.self_exe, &a)
}

fn parse_info(out: &str) -> HashMap<String, String> {
    let mut m = HashMap::new();
    for line in out.lines() {
        if let Some((k, v)) = line.split_once(':') {
            m.insert(k.trim().to_string(), v.trim().to_string());
        }
    }
    m
}

// ---------------------------------------------------------------- compress (streamed progress)
/// Newline-delimited JSON progress stream. The connection stays open and each stage flushes an
/// event as it happens (encode -> verify -> each classical codec -> final record) so the browser
/// can render a live checklist instead of freezing on one long request.
fn stream_open(s: &mut TcpStream) {
    let _ = s.write_all(b"HTTP/1.1 200 OK\r\nContent-Type: application/x-ndjson\r\nCache-Control: no-cache\r\nConnection: close\r\n\r\n");
}
fn stream_line(s: &mut TcpStream, line: &str) {
    let _ = s.write_all(line.as_bytes());
    let _ = s.write_all(b"\n");
    let _ = s.flush();
}

fn stream_compress(ctx: &Ctx, body: &str, s: &mut TcpStream) {
    stream_open(s);
    let b = parse_body(body);
    let path = field(&b, "path");
    if path.is_empty() { stream_line(s, &format!("{{\"stage\":\"error\",\"message\":{}}}", qs("no file path"))); return; }
    let orig = match fs::metadata(path) { Ok(m) if m.is_file() => m.len(),
        _ => { stream_line(s, &format!("{{\"stage\":\"error\",\"message\":{}}}", qs(&format!("not a file: {path}")))); return; } };
    let model = field(&b, "model");
    let want_classical = flag(&b, "classical");
    let verify = !b.contains_key("verify") || flag(&b, "verify");
    let save = !b.contains_key("save") || flag(&b, "save");

    let seq = SEQ.fetch_add(1, Ordering::Relaxed);
    let tmp = std::env::temp_dir().join(format!("syn_studio_{}_{}", std::process::id(), seq));
    if fs::create_dir_all(&tmp).is_err() { stream_line(s, &format!("{{\"stage\":\"error\",\"message\":{}}}", qs("cannot create temp dir"))); return; }
    let base = Path::new(path).file_name().and_then(|x| x.to_str()).unwrap_or("file");
    let nscfile = tmp.join(format!("{base}.nsc"));

    // ---- encode ----
    stream_line(s, &format!("{{\"stage\":\"encode\",\"status\":\"run\",\"file\":{},\"orig_bytes\":{orig}}}", qs(base)));
    let mut args: Vec<&str> = vec!["compress", path, nscfile.to_str().unwrap()];
    if !model.is_empty() { args.push("--model"); args.push(model); }
    if ctx.quiet { args.push("-q"); }
    let t0 = Instant::now();
    let res = nsc(ctx, &args);
    let enc_s = t0.elapsed().as_secs_f64();
    match res {
        Some((_, _, true)) if nscfile.exists() => {}
        Some((o, e, _)) => { let _ = fs::remove_dir_all(&tmp); stream_line(s, &format!("{{\"stage\":\"error\",\"message\":{}}}", qs(&pick_err(&o, &e)))); return; }
        None => { let _ = fs::remove_dir_all(&tmp); stream_line(s, &format!("{{\"stage\":\"error\",\"message\":{}}}", qs("compress failed to run"))); return; }
    }
    let file_bytes = fs::metadata(&nscfile).map(|m| m.len()).unwrap_or(0);
    let info = nsc(ctx, &["info", nscfile.to_str().unwrap()]).map(|(o, _, _)| parse_info(&o)).unwrap_or_default();
    let get = |k: &str| info.get(k).cloned().unwrap_or_default();
    let tokens: u64 = get("tokens").replace(',', "").parse().unwrap_or(0);
    let bpt: Option<f64> = get("bits/token").parse().ok();
    let model_id = if get("model id").is_empty() { model.to_string() } else { get("model id") };
    let bpc = if orig > 0 { file_bytes as f64 * 8.0 / orig as f64 } else { 0.0 };
    let ratio = if file_bytes > 0 { orig as f64 / file_bytes as f64 } else { 0.0 };
    stream_line(s, &format!(
        "{{\"stage\":\"encode\",\"status\":\"done\",\"file_bytes\":{file_bytes},\"tokens\":{tokens},\"bpc\":{:.4},\"ratio\":{:.3},\"encode_s\":{:.4}}}",
        bpc, ratio, enc_s));

    let mut fields: Vec<String> = vec![
        format!("\"ts\":{}", now_secs()),
        format!("\"file\":{}", qs(base)),
        format!("\"path\":{}", qs(path)),
        format!("\"orig_bytes\":{orig}"),
        format!("\"file_bytes\":{file_bytes}"),
        format!("\"tokens\":{tokens}"),
        format!("\"bpc\":{:.4}", bpc),
        format!("\"ratio\":{:.3}", ratio),
        format!("\"model\":{}", qs(&model_id)),
        format!("\"fingerprint\":{}", qs(&get("fingerprint"))),
        format!("\"vocab\":{}", qs(&get("vocab"))),
        format!("\"seg_len\":{}", qs(&get("seg_len"))),
        format!("\"encode_s\":{:.4}", enc_s),
        format!("\"encode_mb_s\":{:.5}", if enc_s > 0.0 { orig as f64 / 1e6 / enc_s } else { 0.0 }),
    ];
    if let Some(v) = bpt { fields.push(format!("\"bits_per_token\":{:.4}", v)); }

    // ---- verify roundtrip ----
    if verify {
        stream_line(s, "{\"stage\":\"verify\",\"status\":\"run\"}");
        let outp = tmp.join("roundtrip.out");
        let t1 = Instant::now();
        let dres = nsc(ctx, &["decompress", nscfile.to_str().unwrap(), outp.to_str().unwrap()]);
        let dec_s = t1.elapsed().as_secs_f64();
        let ok = matches!(dres, Some((_, _, true))) && files_equal(Path::new(path), &outp);
        let dtok = if tokens > 0 && dec_s > 0.0 { tokens as f64 / dec_s } else { 0.0 };
        stream_line(s, &format!("{{\"stage\":\"verify\",\"status\":\"done\",\"roundtrip_ok\":{ok},\"decode_s\":{:.4},\"decode_tok_s\":{:.1}}}", dec_s, dtok));
        fields.push(format!("\"roundtrip_ok\":{ok}"));
        fields.push(format!("\"decode_s\":{:.4}", dec_s));
        if tokens > 0 && dec_s > 0.0 { fields.push(format!("\"decode_tok_s\":{:.1}", dtok)); }
    }

    // ---- classical head-to-head (one event per codec) ----
    if want_classical {
        let mut items: Vec<(String, u64, f64)> = vec![];
        for name in &ctx.classical {
            stream_line(s, &format!("{{\"stage\":\"classical\",\"name\":{},\"status\":\"run\"}}", qs(name)));
            let r = match name.as_str() {
                "gzip -9" => bench_pipe("gzip", &["-9", "-c", path]),
                "xz -9" => bench_pipe("xz", &["-9", "-c", path]),
                "zstd -19" => bench_pipe("zstd", &["-19", "-q", "-c", path]),
                "7z-PPMd" => bench_7z(Path::new(path)),
                _ => None,
            };
            match r {
                Some((bytes, dt)) if bytes > 0 => {
                    let cbpc = if orig > 0 { bytes as f64 * 8.0 / orig as f64 } else { 0.0 };
                    let cratio = if bytes > 0 { orig as f64 / bytes as f64 } else { 0.0 };
                    stream_line(s, &format!("{{\"stage\":\"classical\",\"name\":{},\"status\":\"done\",\"bytes\":{bytes},\"bpc\":{:.4},\"ratio\":{:.3},\"encode_s\":{:.4}}}", qs(name), cbpc, cratio, dt));
                    items.push((name.clone(), bytes, dt));
                }
                _ => stream_line(s, &format!("{{\"stage\":\"classical\",\"name\":{},\"status\":\"skip\"}}", qs(name))),
            }
        }
        items.sort_by_key(|r| r.1);
        let arr: Vec<String> = items.iter().map(|(name, bytes, dt)| {
            let cbpc = if orig > 0 { *bytes as f64 * 8.0 / orig as f64 } else { 0.0 };
            let cratio = if *bytes > 0 { orig as f64 / *bytes as f64 } else { 0.0 };
            let mbs = if *dt > 0.0 { orig as f64 / 1e6 / dt } else { 0.0 };
            format!("{{\"name\":{},\"bytes\":{},\"bpc\":{:.4},\"ratio\":{:.3},\"encode_s\":{:.4},\"encode_mb_s\":{:.5}}}",
                qs(name), bytes, cbpc, cratio, dt, mbs)
        }).collect();
        fields.push(format!("\"classical\":[{}]", arr.join(",")));
    }

    let _ = fs::remove_dir_all(&tmp);
    let rec = format!("{{{}}}", fields.join(","));
    if save { append_history(ctx, &rec); }
    stream_line(s, &format!("{{\"stage\":\"final\",\"record\":{rec}}}"));
}

fn pick_err(o: &str, e: &str) -> String {
    let s = if !e.trim().is_empty() { e } else { o };
    s.lines().rev().find(|l| !l.trim().is_empty()).unwrap_or("compress failed").trim().to_string()
}

fn api_decompress(ctx: &Ctx, body: &str) -> String {
    let b = parse_body(body);
    let path = field(&b, "path");
    let out = field(&b, "out");
    if path.is_empty() || out.is_empty() { return err("need input .nsc and output path"); }
    if !Path::new(path).is_file() { return err(&format!("not a file: {path}")); }
    let t0 = Instant::now();
    match nsc(ctx, &["decompress", path, out]) {
        Some((_, _, true)) => {
            let n = fs::metadata(out).map(|m| m.len()).unwrap_or(0);
            format!("{{\"ok\":true,\"out\":{},\"out_bytes\":{},\"decode_s\":{:.4}}}", qs(out), n, t0.elapsed().as_secs_f64())
        }
        Some((o, e, _)) => err(&pick_err(&o, &e)),
        None => err("decompress failed to run"),
    }
}

// ---------------------------------------------------------------- model management
fn api_model_add(ctx: &Ctx, body: &str) -> String {
    let b = parse_body(body);
    let (id, m, o2, tok) = (field(&b, "id"), field(&b, "model_nsc"), field(&b, "o2"), field(&b, "tokenizer"));
    if id.is_empty() || m.is_empty() || o2.is_empty() || tok.is_empty() { return err("id + 3 files are required"); }
    for (lbl, p) in [("model.nsc", m), ("o2.nsc", o2), ("tokenizer.json", tok)] {
        if !Path::new(p).is_file() { return err(&format!("not a file ({lbl}): {p}")); }
    }
    let today = run_capture(Path::new("date"), &["+%Y-%m-%d".into()]).map(|(o, _, _)| o.trim().to_string()).unwrap_or_default();
    let mut args: Vec<String> = vec!["models".into(), "add".into(), id.into(),
        "--model-nsc".into(), m.into(), "--o2".into(), o2.into(), "--tokenizer".into(), tok.into()];
    if !today.is_empty() { args.push("--created".into()); args.push(today); }
    for (k, f) in [("tier", "tier"), ("bpc", "bpc"), ("notes", "notes")] {
        let v = field(&b, f);
        if !v.is_empty() { args.push(format!("--{k}")); args.push(v.into()); }
    }
    if flag(&b, "make_default") { args.push("--default".into()); }
    args.push("--home".into()); args.push(ctx.home.display().to_string());
    match run_capture(&ctx.self_exe, &args) {
        Some((o, _, true)) => format!("{{\"ok\":true,\"stdout\":{},\"models\":{}}}", qs(o.trim()), models_json(ctx)),
        Some((o, e, _)) => err(&pick_err(&o, &e)),
        None => err("models add failed to run"),
    }
}

fn api_model_default(ctx: &Ctx, body: &str) -> String {
    let id = field(&parse_body(body), "id").to_string();
    if id.is_empty() { return err("no id"); }
    match nsc(ctx, &["models", "default", &id]) {
        Some((_, _, true)) => format!("{{\"ok\":true,\"models\":{}}}", models_json(ctx)),
        Some((o, e, _)) => err(&pick_err(&o, &e)),
        None => err("failed to run"),
    }
}

fn api_model_remove(ctx: &Ctx, body: &str) -> String {
    let id = field(&parse_body(body), "id").to_string();
    if id.is_empty() { return err("no id"); }
    match nsc(ctx, &["models", "remove", &id]) {
        Some((_, _, true)) => format!("{{\"ok\":true,\"models\":{}}}", models_json(ctx)),
        Some((o, e, _)) => err(&pick_err(&o, &e)),
        None => err("failed to run"),
    }
}

// ---------------------------------------------------------------- history
fn read_history(ctx: &Ctx) -> String {
    fs::read_to_string(&ctx.hist_path).ok().filter(|s| !s.trim().is_empty()).unwrap_or_else(|| "[]".into())
}

fn append_history(ctx: &Ctx, rec: &str) {
    let _guard = ctx.hist_lock.lock().unwrap();
    let cur = fs::read_to_string(&ctx.hist_path).unwrap_or_default();
    let trimmed = cur.trim();
    let new = if trimmed.is_empty() || trimmed == "[]" {
        format!("[{rec}]")
    } else if let Some(pos) = trimmed.rfind(']') {
        format!("{},{}]", &trimmed[..pos], rec)
    } else {
        format!("[{rec}]")
    };
    let tmp = ctx.hist_path.with_extension("json.tmp");
    if fs::write(&tmp, new).is_ok() { let _ = fs::rename(&tmp, &ctx.hist_path); }
}

// ---------------------------------------------------------------- file browse
fn api_browse(path: &str, root: &Path) -> String {
    let start = if path.is_empty() {
        root.to_path_buf()
    } else {
        expand_home(path)
    };
    let dir = if start.is_dir() { start.clone() } else {
        start.parent().map(|p| p.to_path_buf()).unwrap_or_else(|| PathBuf::from("/"))
    };
    let dir = fs::canonicalize(&dir).unwrap_or(dir);
    let mut entries: Vec<(String, PathBuf, bool, u64)> = vec![];
    match fs::read_dir(&dir) {
        Ok(rd) => {
            for e in rd.flatten() {
                let p = e.path();
                let name = e.file_name().to_string_lossy().into_owned();
                let is_dir = p.is_dir();
                let sz = if is_dir { 0 } else { fs::metadata(&p).map(|m| m.len()).unwrap_or(0) };
                entries.push((name, p, is_dir, sz));
            }
        }
        Err(_) => return format!("{{\"error\":\"cannot read dir\",\"path\":{}}}", qs(&dir.display().to_string())),
    }
    entries.sort_by(|a, b| b.2.cmp(&a.2).then(a.0.to_lowercase().cmp(&b.0.to_lowercase())));
    let items: Vec<String> = entries.iter().map(|(name, p, is_dir, sz)| {
        format!("{{\"name\":{},\"path\":{},\"dir\":{},\"size\":{}}}",
            qs(name), qs(&p.display().to_string()), is_dir, sz)
    }).collect();
    let parent = dir.parent().map(|p| p.display().to_string()).unwrap_or_else(|| dir.display().to_string());
    format!("{{\"path\":{},\"parent\":{},\"entries\":[{}]}}",
        qs(&dir.display().to_string()), qs(&parent), items.join(","))
}

fn expand_home(p: &str) -> PathBuf {
    if let Some(rest) = p.strip_prefix("~") {
        if let Ok(h) = std::env::var("HOME") {
            return PathBuf::from(h).join(rest.trim_start_matches('/'));
        }
    }
    PathBuf::from(p)
}

// ---------------------------------------------------------------- misc

fn err(msg: &str) -> String { format!("{{\"error\":{}}}", qs(msg)) }

fn now_secs() -> u64 {
    std::time::SystemTime::now().duration_since(std::time::UNIX_EPOCH).map(|d| d.as_secs()).unwrap_or(0)
}

fn query_get(query: &str, key: &str) -> String {
    for pair in query.split('&') {
        if let Some((k, v)) = pair.split_once('=') {
            if k == key { return percent_decode(v); }
        }
    }
    String::new()
}

fn percent_decode(s: &str) -> String {
    let b = s.replace('+', " ");
    let bytes = b.as_bytes();
    let mut out = Vec::with_capacity(bytes.len());
    let mut i = 0;
    while i < bytes.len() {
        if bytes[i] == b'%' && i + 2 < bytes.len() {
            let h = hex(bytes[i + 1]).zip(hex(bytes[i + 2]));
            if let Some((hi, lo)) = h { out.push(hi * 16 + lo); i += 3; continue; }
        }
        out.push(bytes[i]);
        i += 1;
    }
    String::from_utf8_lossy(&out).into_owned()
}
fn hex(b: u8) -> Option<u8> {
    match b { b'0'..=b'9' => Some(b - b'0'), b'a'..=b'f' => Some(b - b'a' + 10), b'A'..=b'F' => Some(b - b'A' + 10), _ => None }
}
