//! `nsc` — neuro-symbolic lossless codec CLI.
//!
//! A byte-exact port of `int8_codec.py`: the int8 GRU + RoPE transformer + gate + fusion, the
//! classical order-0/1/2 + match feature model, and a range coder — all in dependency-free Rust.
//! Byte↔token conversion is delegated to `tok.py` (the one Python touch-point).
//!
//! This binary is built around a **versioned model registry** so models can be upgraded safely:
//! each compressed file records the id + fingerprint of the model that produced it, so a file is
//! always decompressed by the exact model it was compressed with — even after the default model is
//! upgraded. Batch mode loads the model once and compresses many files across CPU cores.
mod artifacts;
mod bench;
mod codec;
mod container;
mod features;
mod forward;
mod range_coder;
mod registry;
mod selftest;
mod studio;

use artifacts::Model;
use features::O2Table;
use registry::{ModelDir, Registry};
use std::collections::{HashMap, HashSet};
use std::path::{Path, PathBuf};
use std::sync::Mutex;
use std::sync::atomic::{AtomicU64, Ordering};

// ------------------------------------------------------------------ arg parsing
/// Flags that take a following value; everything else `--x` is a boolean flag.
const VALUE_FLAGS: &[&str] = &["model", "home", "out-dir", "jobs", "tier", "bpc", "notes",
                               "created", "model-nsc", "o2", "tokenizer", "port", "root",
                               "levels", "only", "report", "nsc-jobs", "max-mb"];

struct Cli {
    positionals: Vec<String>,
    kv: HashMap<String, String>,
    flags: HashSet<String>,
}
impl Cli {
    fn get(&self, k: &str) -> Option<&str> { self.kv.get(k).map(|s| s.as_str()) }
    fn has(&self, k: &str) -> bool { self.flags.contains(k) }
    fn quiet(&self) -> bool { self.has("quiet") || self.has("q") }
}

fn parse_args(argv: &[String]) -> Result<(String, Cli), String> {
    // The command is the first bare word; flags may appear before or after it.
    let mut cmd: Option<String> = None;
    let mut cli = Cli { positionals: vec![], kv: HashMap::new(), flags: HashSet::new() };
    let mut i = 0usize;
    while i < argv.len() {
        let a = &argv[i];
        if let Some(key) = a.strip_prefix("--") {
            if VALUE_FLAGS.contains(&key) {
                let v = argv.get(i + 1).ok_or_else(|| format!("flag --{key} needs a value"))?;
                cli.kv.insert(key.to_string(), v.clone());
                i += 2;
            } else {
                cli.flags.insert(key.to_string());
                i += 1;
            }
        } else if a == "-q" { cli.flags.insert("q".into()); i += 1; }
        else if a == "-h" { cli.flags.insert("help".into()); i += 1; }
        else {
            if cmd.is_none() { cmd = Some(a.clone()); } else { cli.positionals.push(a.clone()); }
            i += 1;
        }
    }
    Ok((cmd.unwrap_or_else(|| "help".into()), cli))
}

fn open_registry(cli: &Cli) -> Result<Registry, String> {
    match cli.get("home") {
        Some(h) => Ok(Registry::with_home(PathBuf::from(h))),
        None => Registry::open(),
    }
}

fn p2s(p: &Path) -> String { p.to_string_lossy().into_owned() }

/// Worker threads for a single-file encode: `--jobs` if given, else the CPU count. Encode windows
/// are independent, so this parallelises the neural forward (`batch` passes 1 — it already runs one
/// job per file).
fn jobs_from_cli(cli: &Cli) -> usize {
    cli.get("jobs").and_then(|s| s.parse::<usize>().ok()).filter(|&j| j > 0)
        .unwrap_or_else(|| std::thread::available_parallelism().map(|n| n.get()).unwrap_or(1))
}

fn load_pair(m: &ModelDir) -> (Model, O2Table) {
    (Model::load(&p2s(&m.model_nsc())), O2Table::load(&p2s(&m.o2_nsc())))
}

// ------------------------------------------------------------------ tokenizer bridge
static TMP_CTR: AtomicU64 = AtomicU64::new(0);
fn temp_ids() -> PathBuf {
    let n = TMP_CTR.fetch_add(1, Ordering::Relaxed);
    let t = std::time::SystemTime::now().duration_since(std::time::UNIX_EPOCH).map(|d| d.as_nanos()).unwrap_or(0);
    std::env::temp_dir().join(format!("nsc-{}-{}-{}.ids", std::process::id(), t, n))
}

/// Run the tokenizer shim: `python3 tok.py {enc|dec} <a> <b> <model-tokenizer.json>`.
fn run_tok(reg: &Registry, model: &ModelDir, mode: &str, a: &Path, b: &Path, quiet: bool) -> Result<(), String> {
    let py = std::env::var("NSC_PYTHON").unwrap_or_else(|_| "python3".into());
    let tok = reg.tok_py();
    if !tok.exists() { return Err(format!("tokenizer shim not found: {} (set NSC_TOK or reinstall)", tok.display())); }
    let mut c = std::process::Command::new(&py);
    c.arg(&tok).arg(mode).arg(a).arg(b).arg(model.tokenizer());
    if quiet { c.stdout(std::process::Stdio::null()); }
    let status = c.status().map_err(|e| format!("failed to launch {py}: {e} (is python3 on PATH?)"))?;
    if !status.success() { return Err(format!("tokenizer step '{mode}' failed")); }
    Ok(())
}

// ------------------------------------------------------------------ core encode/decode (one file)
fn encode_file(m: &Model, o2: &O2Table, model_id: &str, fp: u64, in_ids: &Path, out_nsc: &Path, jobs: usize) -> Result<(usize, usize), String> {
    let tokens = codec::read_ids(&p2s(in_ids))?;
    if tokens.is_empty() { return Err("empty token stream".into()); }
    let (payload, nbits) = codec::encode_tokens(m, o2, &tokens, jobs);
    container::write(&p2s(out_nsc), model_id, fp, m.cfg.vocab_size, m.cfg.seg_len,
                     tokens.len(), tokens[0], nbits, &payload)?;
    Ok((tokens.len(), payload.len()))
}

fn decode_file(m: &Model, o2: &O2Table, in_nsc: &Path, out_ids: &Path) -> Result<usize, String> {
    let c = container::read(&p2s(in_nsc))?;
    if c.header.vocab != m.cfg.vocab_size {
        return Err(format!("container vocab {} != model vocab {}", c.header.vocab, m.cfg.vocab_size));
    }
    let rec = codec::decode_tokens(m, o2, c.header.first, c.header.n, c.payload, c.header.n_bits);
    codec::write_ids(&p2s(out_ids), &rec)?;
    Ok(rec.len())
}

/// Pick the model to decompress with: explicit override > id recorded in the file > registry default.
/// Enforces the fingerprint recorded in the file so a swapped/tampered registry is caught.
fn model_for_decompress(reg: &Registry, cli: &Cli, header: &container::Header) -> Result<ModelDir, String> {
    let id = cli.get("model").or(header.model_id.as_deref());
    let model = reg.resolve(id)?;
    if header.fingerprint != 0 && header.fingerprint != model.manifest.fingerprint {
        return Err(format!(
            "model fingerprint mismatch for '{}': this file was produced by a different build of that \
             model than the one installed. Install the exact model version to decompress it.",
            model.manifest.id));
    }
    Ok(model)
}

// ------------------------------------------------------------------ commands: compress / decompress
/// Decide whether the neural (text/code) path applies. Already-compressed or binary input (mp4,
/// images, archives) would only be *expanded* by the neural model — and tokenizing a large binary
/// can exhaust memory — so such files are stored verbatim instead. Samples a prefix: a NUL byte or
/// a high density of control characters marks the file as non-textual (git's binary-detection rule).
fn looks_textual(path: &Path) -> bool {
    let mut f = match std::fs::File::open(path) { Ok(f) => f, Err(_) => return true }; // let the normal path surface the error
    let mut buf = [0u8; 8192];
    let n = std::io::Read::read(&mut f, &mut buf).unwrap_or(0);
    if n == 0 { return true; } // empty -> let the normal path report "empty token stream"
    let sample = &buf[..n];
    if sample.contains(&0) { return false; } // NUL => binary
    let ctrl = sample.iter().filter(|&&b| (b < 0x20 && b != 9 && b != 10 && b != 13) || b == 0x7f).count();
    (ctrl as f64) / (n as f64) < 0.05
}

/// Store a file verbatim (raw fallback) and print a summary. Guarantees byte-exact round-trip for
/// any input; `reason` explains why the neural path was skipped.
fn store_and_report(input: &str, output: &str, reason: &str, quiet: bool) -> Result<(), String> {
    let in_bytes = std::fs::metadata(input).map(|m| m.len()).unwrap_or(0);
    let out_bytes = container::write_stored(output, Path::new(input))?;
    if !quiet {
        let ratio = if out_bytes > 0 { in_bytes as f64 / out_bytes as f64 } else { 0.0 };
        println!("compress: {} -> {}  [stored: {}]  {} B -> {} B  ({:.2}x, neural skipped)",
                 input, output, reason, in_bytes, out_bytes, ratio);
    }
    Ok(())
}

fn cmd_compress(reg: &Registry, cli: &Cli) -> Result<(), String> {
    let (input, output) = two_positionals(cli, "compress", "<input> <output.nsc>")?;
    // Universal fallback: binary/incompressible input (mp4, images, archives) or `--store` is stored
    // verbatim rather than fed to the neural model. `--neural` forces the model path regardless.
    if !cli.has("neural") && (cli.has("store") || !looks_textual(Path::new(&input))) {
        let reason = if cli.has("store") { "forced" } else { "binary" };
        return store_and_report(&input, &output, reason, cli.quiet());
    }
    let model = reg.resolve(cli.get("model"))?;
    let in_bytes = std::fs::metadata(&input).map(|md| md.len()).unwrap_or(0);
    let tmp = temp_ids();
    let neural = (|| -> Result<(usize, usize), String> {
        run_tok(reg, &model, "enc", Path::new(&input), &tmp, cli.quiet())?;
        let (m, o2) = load_pair(&model);
        encode_file(&m, &o2, &model.manifest.id, model.manifest.fingerprint, &tmp, Path::new(&output), jobs_from_cli(cli))
    })();
    if !cli.has("keep-ids") { let _ = std::fs::remove_file(&tmp); }
    match neural {
        // Neural won: keep it only if it actually beat storing the bytes raw.
        Ok((ntok, pbytes)) if in_bytes == 0 || (pbytes as u64) < in_bytes => {
            if !cli.quiet() {
                let bpb = if in_bytes > 0 { pbytes as f64 * 8.0 / in_bytes as f64 } else { 0.0 };
                let ratio = if pbytes > 0 { in_bytes as f64 / pbytes as f64 } else { 0.0 };
                println!("compress: {} -> {}  [model {}]  {} B -> {} tok -> {} B  ({:.3} bits/byte, {:.2}x)",
                         input, output, model.manifest.id, in_bytes, ntok, pbytes, bpb, ratio);
            }
            Ok(())
        }
        // Neural expanded the file: store raw instead so the ratio is never worse than ~1.0.
        Ok((_ntok, pbytes)) => {
            if !cli.quiet() { eprintln!("note: neural output {pbytes} B >= input {in_bytes} B; storing raw instead"); }
            store_and_report(&input, &output, "incompressible", cli.quiet())
        }
        // Neural path failed (e.g. tokenizer OOM on a huge file): never error — store raw instead.
        Err(e) => {
            if !cli.quiet() { eprintln!("note: neural compression unavailable ({e}); storing raw instead"); }
            store_and_report(&input, &output, "fallback", cli.quiet())
        }
    }
}

fn cmd_decompress(reg: &Registry, cli: &Cli) -> Result<(), String> {
    let (input, output) = two_positionals(cli, "decompress", "<input.nsc> <output>")?;
    let header = container::read_header(&input)?;
    if header.stored {
        let n = container::extract_stored(&input, &output)?;
        if !cli.quiet() { println!("decompress: {} -> {}  [stored]  {} bytes", input, output, n); }
        return Ok(());
    }
    let model = model_for_decompress(reg, cli, &header)?;
    let tmp = temp_ids();
    let r = (|| {
        let (m, o2) = load_pair(&model);
        let ntok = decode_file(&m, &o2, Path::new(&input), &tmp)?;
        run_tok(reg, &model, "dec", &tmp, Path::new(&output), cli.quiet())?;
        if !cli.quiet() {
            println!("decompress: {} -> {}  [model {}]  {} tokens", input, output, model.manifest.id, ntok);
        }
        Ok(())
    })();
    if !cli.has("keep-ids") { let _ = std::fs::remove_file(&tmp); }
    r
}

// ------------------------------------------------------------------ commands: *-ids (no tokenizer)
fn cmd_compress_ids(reg: &Registry, cli: &Cli) -> Result<(), String> {
    let (input, output) = two_positionals(cli, "compress-ids", "<in.ids> <out.nsc>")?;
    let model = reg.resolve(cli.get("model"))?;
    let (m, o2) = load_pair(&model);
    let (ntok, pbytes) = encode_file(&m, &o2, &model.manifest.id, model.manifest.fingerprint, Path::new(&input), Path::new(&output), jobs_from_cli(cli))?;
    if !cli.quiet() {
        let bpt = if ntok > 1 { pbytes as f64 * 8.0 / (ntok - 1) as f64 } else { 0.0 };
        println!("compress-ids: {} tok -> {} ({} B, {:.4} bits/token)  [model {}]", ntok, output, pbytes, bpt, model.manifest.id);
    }
    Ok(())
}

fn cmd_decompress_ids(reg: &Registry, cli: &Cli) -> Result<(), String> {
    let (input, output) = two_positionals(cli, "decompress-ids", "<in.nsc> <out.ids>")?;
    let header = container::read_header(&input)?;
    let model = model_for_decompress(reg, cli, &header)?;
    let (m, o2) = load_pair(&model);
    let ntok = decode_file(&m, &o2, Path::new(&input), Path::new(&output))?;
    if !cli.quiet() { println!("decompress-ids: {} -> {} ({} tokens)  [model {}]", input, output, ntok, model.manifest.id); }
    Ok(())
}

// ------------------------------------------------------------------ command: batch (scalability)
fn out_path(input: &str, out_dir: Option<&str>, add: bool) -> PathBuf {
    let inp = Path::new(input);
    if add {
        // compress: <name>.nsc
        let name = format!("{}.nsc", inp.file_name().map(|s| s.to_string_lossy().into_owned()).unwrap_or_else(|| "out".into()));
        out_dir.map(|d| Path::new(d).join(&name)).unwrap_or_else(|| PathBuf::from(format!("{input}.nsc")))
    } else {
        // decompress: strip .nsc (else append .out)
        let base: PathBuf = if input.ends_with(".nsc") { PathBuf::from(&input[..input.len() - 4]) } else { PathBuf::from(format!("{input}.out")) };
        match out_dir {
            Some(d) => Path::new(d).join(base.file_name().unwrap_or_default()),
            None => base,
        }
    }
}

fn cmd_batch(reg: &Registry, cli: &Cli) -> Result<(), String> {
    let sub = cli.positionals.first().map(|s| s.as_str()).ok_or("usage: nsc batch <compress|decompress> <files...>")?;
    let files: Vec<String> = cli.positionals[1..].to_vec();
    if files.is_empty() { return Err("batch: no input files given".into()); }
    let compress = match sub {
        "compress" => true,
        "decompress" => false,
        other => return Err(format!("batch: unknown sub-command '{other}' (use compress|decompress)")),
    };
    if let Some(d) = cli.get("out-dir") { std::fs::create_dir_all(d).map_err(|e| format!("mkdir {d}: {e}"))?; }
    let jobs = cli.get("jobs").and_then(|s| s.parse::<usize>().ok())
        .unwrap_or_else(|| std::thread::available_parallelism().map(|n| n.get()).unwrap_or(1))
        .max(1);

    // For decompress, every file may reference a different model; group is simplest if we resolve
    // per file. For compress, all files share one model — load it once. Both share ONE loaded model
    // per distinct id. Here we load lazily and cache by id.
    let out_dir = cli.get("out-dir");
    let keep_ids = cli.has("keep-ids");
    let quiet = cli.quiet();

    // Resolve+load each needed model once (compress: the chosen model; decompress: per-file id).
    // Cache: id -> (ModelDir, Model, O2Table). Built up-front single-threaded (loads are 273 MB).
    // model_id is None for files handled by the raw-stored fallback (binary/`--store` on compress,
    // or NSCR files on decompress): those need no model, so we don't resolve or load one for them.
    let force_store = cli.has("store");
    let force_neural = cli.has("neural");
    let mut cache: HashMap<String, (ModelDir, Model, O2Table)> = HashMap::new();
    let mut plan: Vec<(Option<String>, String, PathBuf)> = Vec::with_capacity(files.len());
    for f in &files {
        let (id, out) = if compress {
            let out = out_path(f, out_dir, true);
            if !force_neural && (force_store || !looks_textual(Path::new(f))) {
                (None, out) // stored fallback — no model
            } else {
                let md = reg.resolve(cli.get("model"))?;
                let id = md.manifest.id.clone();
                cache.entry(id.clone()).or_insert_with(|| { let (m, o2) = load_pair(&md); (md, m, o2) });
                (Some(id), out)
            }
        } else {
            let out = out_path(f, out_dir, false);
            let header = container::read_header(f)?;
            if header.stored { (None, out) } else {
                let md = model_for_decompress(reg, cli, &header)?;
                let id = md.manifest.id.clone();
                cache.entry(id.clone()).or_insert_with(|| { let (m, o2) = load_pair(&md); (md, m, o2) });
                (Some(id), out)
            }
        };
        plan.push((id, f.clone(), out));
    }

    println!("batch {}: {} files, {} job(s), {} model(s) loaded", sub, files.len(), jobs, cache.len());
    let results: Mutex<Vec<(String, Result<String, String>)>> = Mutex::new(Vec::new());
    let next = AtomicU64::new(0);
    std::thread::scope(|s| {
        for _ in 0..jobs {
            s.spawn(|| {
                loop {
                    let idx = next.fetch_add(1, Ordering::Relaxed) as usize;
                    if idx >= plan.len() { break; }
                    let (id, input, output) = &plan[idx];
                    let model = id.as_ref().map(|i| { let (md, m, o2) = &cache[i]; (md, m, o2) });
                    let r = process_one(reg, model, input, output, compress, keep_ids, quiet);
                    results.lock().unwrap().push((input.clone(), r));
                }
            });
        }
    });

    let mut done = results.into_inner().unwrap();
    done.sort_by(|a, b| a.0.cmp(&b.0));
    let mut ok = 0usize;
    for (input, r) in &done {
        match r {
            Ok(msg) => { ok += 1; if !quiet { println!("  ✓ {input}: {msg}"); } }
            Err(e) => eprintln!("  ✗ {input}: {e}"),
        }
    }
    println!("batch {}: {}/{} succeeded", sub, ok, done.len());
    if ok < done.len() { return Err(format!("{} file(s) failed", done.len() - ok)); }
    Ok(())
}

/// One batch item. `model` is None when the raw-stored fallback applies (binary/`--store` on
/// compress, NSCR on decompress); otherwise it is the resolved+loaded model. Never returns an error
/// for a normal compress: if the neural path fails or expands, it falls back to storing the bytes.
fn process_one(reg: &Registry, model: Option<(&ModelDir, &Model, &O2Table)>, input: &str, output: &Path,
               compress: bool, keep_ids: bool, quiet: bool) -> Result<String, String> {
    let _ = quiet;
    if compress {
        let (md, m, o2) = match model {
            None => { let n = container::write_stored(&p2s(output), Path::new(input))?; return Ok(format!("stored -> {} ({} B, binary)", output.display(), n)); }
            Some(t) => t,
        };
        let in_bytes = std::fs::metadata(input).map(|md| md.len()).unwrap_or(0);
        let tmp = temp_ids();
        let neural = (|| {
            run_tok(reg, md, "enc", Path::new(input), &tmp, true)?;
            // batch runs one job per file already, so keep each encode single-threaded.
            encode_file(m, o2, &md.manifest.id, md.manifest.fingerprint, &tmp, output, 1)
        })();
        if !keep_ids { let _ = std::fs::remove_file(&tmp); }
        match neural {
            Ok((ntok, pbytes)) if in_bytes == 0 || (pbytes as u64) < in_bytes =>
                Ok(format!("{} tok -> {} ({} B)", ntok, output.display(), pbytes)),
            Ok((_ntok, _pbytes)) => {
                let n = container::write_stored(&p2s(output), Path::new(input))?;
                Ok(format!("stored -> {} ({} B, incompressible)", output.display(), n))
            }
            Err(e) => {
                let n = container::write_stored(&p2s(output), Path::new(input))?;
                Ok(format!("stored -> {} ({} B, fallback: {})", output.display(), n, e))
            }
        }
    } else {
        match model {
            None => { let n = container::extract_stored(input, &p2s(output))?; Ok(format!("stored -> {} ({} bytes)", output.display(), n)) }
            Some((md, m, o2)) => {
                let tmp = temp_ids();
                let r = (|| {
                    let ntok = decode_file(m, o2, Path::new(input), &tmp)?;
                    run_tok(reg, md, "dec", &tmp, output, true)?;
                    Ok(format!("{} tok -> {}", ntok, output.display()))
                })();
                if !keep_ids { let _ = std::fs::remove_file(&tmp); }
                r
            }
        }
    }
}

// ------------------------------------------------------------------ command: bench
fn cmd_bench(cli: &Cli) -> Result<(), String> {
    if cli.positionals.is_empty() {
        return Err("usage: nsc bench <files|dirs...> [--classical] [--levels 1,5,9] [--only a,b] [--report out.json] [--no-verify] [--nsc-jobs N] [--max-mb N]".into());
    }
    let parse_list = |k: &str| cli.get(k).map(|v| v.split(',').map(|x| x.trim().to_string()).filter(|x| !x.is_empty()).collect::<Vec<_>>());
    let levels: Vec<u32> = match parse_list("levels") {
        Some(v) => v.iter().map(|x| x.parse::<u32>().map_err(|_| format!("bad level '{x}'"))).collect::<Result<_, _>>()?,
        None => vec![],
    };
    let opts = bench::BenchOpts {
        paths: cli.positionals.clone(),
        classical: cli.has("classical") || levels.is_empty(),
        levels,
        only: parse_list("only"),
        json: cli.get("report").map(|s| s.to_string()),
        verify: !cli.has("no-verify"),
        nsc_jobs: cli.get("nsc-jobs").and_then(|s| s.parse().ok()).filter(|&j: &usize| j > 0).unwrap_or(1),
        max_bytes: cli.get("max-mb").and_then(|s| s.parse::<u64>().ok()).map(|mb| mb * 1_000_000),
    };
    bench::run(&opts)
}

// ------------------------------------------------------------------ command: info
fn cmd_info(cli: &Cli) -> Result<(), String> {
    let f = cli.positionals.first().ok_or("usage: nsc info <file.nsc>")?;
    let h = container::read_header(f)?;
    let size = std::fs::metadata(f).map(|m| m.len()).unwrap_or(0);
    if h.stored {
        println!("file:        {f}");
        println!("format:      NSCR (stored — raw fallback, no neural compression)");
        println!("original:    {} bytes", h.n);
        println!("file size:   {} bytes", size);
        return Ok(());
    }
    println!("file:        {f}");
    println!("format:      {}", if h.model_id.is_some() { "NSC2 (versioned)" } else { "NSCZ (legacy)" });
    println!("model id:    {}", h.model_id.as_deref().unwrap_or("(none — legacy file)"));
    if h.fingerprint != 0 { println!("fingerprint: {:#018x}", h.fingerprint); }
    println!("vocab:       {}", h.vocab);
    println!("seg_len:     {}", h.seg);
    println!("tokens:      {}", h.n);
    println!("file size:   {} bytes", size);
    if h.n > 1 { println!("bits/token:  {:.4}", h.n_bits as f64 / (h.n - 1) as f64); }
    Ok(())
}

// ------------------------------------------------------------------ command: models
fn short_fp(fp: u64) -> String { format!("{:08x}", (fp >> 32) as u32) }

fn cmd_models(reg: &Registry, cli: &Cli) -> Result<(), String> {
    let sub = cli.positionals.first().map(|s| s.as_str()).unwrap_or("list");
    match sub {
        "list" => {
            let models = reg.list()?;
            let def = reg.default_id();
            println!("registry: {}", reg.home().display());
            if models.is_empty() { println!("  (no models installed — run install.sh or `nsc models add ...`)"); return Ok(()); }
            println!("  {:<16} {:<3} {:<6} {:<7} {:<8} {:<10} {}", "ID", "DEF", "TIER", "VOCAB", "BPC", "CREATED", "FINGERPRINT");
            for m in &models {
                let man = &m.manifest;
                let is_def = if def.as_deref() == Some(&man.id) { "*" } else { "" };
                println!("  {:<16} {:<3} {:<6} {:<7} {:<8.3} {:<10} {}",
                    man.id, is_def, man.tier, man.vocab_size, man.bpc, man.created, short_fp(man.fingerprint));
            }
            Ok(())
        }
        "add" => {
            let id = cli.positionals.get(1).ok_or("usage: nsc models add <id> --model-nsc <p> --o2 <p> --tokenizer <p> [--tier t --bpc x --notes s --created YYYY-MM-DD --default]")?;
            let src_model = cli.get("model-nsc").ok_or("models add: --model-nsc <path> required")?;
            let src_o2 = cli.get("o2").ok_or("models add: --o2 <path> required")?;
            let src_tok = cli.get("tokenizer").ok_or("models add: --tokenizer <path> required")?;
            let tier = cli.get("tier").unwrap_or("");
            let bpc = cli.get("bpc").and_then(|s| s.parse::<f64>().ok()).unwrap_or(0.0);
            let created = cli.get("created").unwrap_or("");
            let notes = cli.get("notes").unwrap_or("");
            let man = reg.add(id, Path::new(src_model), Path::new(src_o2), Path::new(src_tok),
                              tier, bpc, created, notes, cli.has("default"))?;
            let is_def = reg.default_id().as_deref() == Some(id);
            println!("added model '{}' (vocab {}, seg {}, fp {}){}",
                     man.id, man.vocab_size, man.seg_len, short_fp(man.fingerprint),
                     if is_def { "  [now default]" } else { "" });
            Ok(())
        }
        "default" => {
            let id = cli.positionals.get(1).ok_or("usage: nsc models default <id>")?;
            reg.set_default(id)?;
            println!("default model set to '{id}'");
            Ok(())
        }
        "remove" | "rm" => {
            let id = cli.positionals.get(1).ok_or("usage: nsc models remove <id>")?;
            reg.remove(id)?;
            println!("removed model '{id}'");
            Ok(())
        }
        other => Err(format!("unknown 'models' sub-command '{other}' (use list|add|default|remove)")),
    }
}

// ------------------------------------------------------------------ command: doctor
fn cmd_doctor(reg: &Registry, cli: &Cli) -> Result<(), String> {
    let mut problems = 0usize;
    println!("registry home: {}", reg.home().display());
    // python + tok.py
    let py = std::env::var("NSC_PYTHON").unwrap_or_else(|_| "python3".into());
    let tok = reg.tok_py();
    match std::process::Command::new(&py).arg("--version").stdout(std::process::Stdio::null()).stderr(std::process::Stdio::null()).status() {
        Ok(s) if s.success() => println!("python:        {py}  ✓"),
        _ => { println!("python:        {py}  ✗ (not runnable — end-to-end compress/decompress needs it)"); problems += 1; }
    }
    println!("tok.py:        {}  {}", tok.display(), if tok.exists() { "✓" } else { problems += 1; "✗ (missing)" });
    // models
    let models = reg.list()?;
    let def = reg.default_id();
    println!("default model: {}", def.as_deref().unwrap_or("(none set)"));
    if models.is_empty() { println!("models:        none installed"); problems += 1; }
    let verify = cli.has("verify");
    for m in &models {
        let man = &m.manifest;
        let mut notes = vec![];
        for (label, p) in [("model.nsc", m.model_nsc()), ("o2.nsc", m.o2_nsc()), ("tokenizer.json", m.tokenizer())] {
            if !p.exists() { notes.push(format!("missing {label}")); problems += 1; }
        }
        if verify && notes.is_empty() {
            match registry::fingerprint(&m.model_nsc(), &m.o2_nsc()) {
                Ok(fp) if fp == man.fingerprint => notes.push("fingerprint ✓".into()),
                Ok(_) => { notes.push("FINGERPRINT MISMATCH".into()); problems += 1; }
                Err(e) => { notes.push(format!("hash error: {e}")); problems += 1; }
            }
        }
        println!("  model {:<16} {}", man.id, if notes.is_empty() { "ok".into() } else { notes.join(", ") });
    }
    if !verify { println!("(run `nsc doctor --verify` to re-hash and check model fingerprints)"); }
    if problems == 0 { println!("\nall checks passed ✓"); Ok(()) }
    else { Err(format!("{problems} problem(s) found")) }
}

// ------------------------------------------------------------------ helpers / help
fn two_positionals(cli: &Cli, cmd: &str, usage: &str) -> Result<(String, String), String> {
    if cli.positionals.len() < 2 { return Err(format!("usage: nsc {cmd} {usage}")); }
    Ok((cli.positionals[0].clone(), cli.positionals[1].clone()))
}

fn print_help() {
    println!("\
nsc {ver} — neuro-symbolic lossless codec

USAGE
  nsc <command> [args] [flags]

COMMANDS
  compress    <input> <output.nsc>     Compress a file end-to-end (auto tokenize + code).
                                       Binary/already-compressed input (mp4, images, archives) is
                                       stored verbatim instead — always lossless, never fails.
  decompress  <input.nsc> <output>     Decompress; auto-selects the model recorded in the file.
  compress-ids   <in.ids> <out.nsc>    Compress a pre-tokenized .ids file (no tokenizer).
  decompress-ids <in.nsc> <out.ids>    Decompress to a .ids file (no tokenizer).
  batch <compress|decompress> <files...>   Process many files; model loaded once (see --jobs).
  info   <file.nsc>                    Show a compressed file's header (model, tokens, ratio).
  models [list]                        List installed models (* = default).
  models add <id> --model-nsc <p> --o2 <p> --tokenizer <p> [--tier t --bpc x --notes s --default]
  models default <id>                  Set the default model for new compressions.
  models remove <id>                   Remove a model version.
  doctor [--verify]                    Check registry, python/tok.py, and (‑‑verify) fingerprints.
  bench <files|dirs...>                Benchmark nsc levels vs gzip/bzip2/zstd/xz/7z: ratio, MB/s, peak
                                       RSS, roundtrip check. [--classical] [--levels 1,5,9] [--only a,b]
                                       [--report out.json] [--no-verify] [--nsc-jobs N] [--max-mb N]
  studio [--port N] [--root DIR]       Launch the local web dashboard (compress, metrics, upgrades).
                                       --root sets where the file browser opens (default: current dir).
  selftest                             Developer parity harness (Stages A–E) vs artifacts/.
  version | help

FLAGS
  --model <id>     Model to compress with (default: registry default).
  --home <path>    Registry home (default: $NSC_HOME or ~/.nsc).
  --jobs <n>       Parallel workers for `batch` (default: CPU count).
  --out-dir <dir>  Output directory for `batch`.
  --keep-ids       Keep the intermediate .ids file.
  --store          Force the raw-stored fallback (skip the neural model) for this compress.
  --neural         Force the neural model even for binary-looking input (kept only if it wins).
  -q, --quiet      Reduce output.

Model upgrading: every .nsc file records the id + fingerprint of the model that made it, so old
files keep decompressing after you `nsc models add` a newer default. See README.md.", ver = env!("CARGO_PKG_VERSION"));
}

fn dispatch(cmd: &str, cli: &Cli) -> Result<(), String> {
    match cmd {
        "compress" => cmd_compress(&open_registry(cli)?, cli),
        "decompress" => cmd_decompress(&open_registry(cli)?, cli),
        "compress-ids" => cmd_compress_ids(&open_registry(cli)?, cli),
        "decompress-ids" => cmd_decompress_ids(&open_registry(cli)?, cli),
        "batch" => cmd_batch(&open_registry(cli)?, cli),
        "info" => cmd_info(cli),
        "bench" => cmd_bench(cli),
        "models" => cmd_models(&open_registry(cli)?, cli),
        "doctor" => cmd_doctor(&open_registry(cli)?, cli),
        "studio" => studio::run(open_registry(cli)?, cli),
        "selftest" => { selftest::run(); Ok(()) }
        "version" | "--version" => { println!("nsc {}", env!("CARGO_PKG_VERSION")); Ok(()) }
        "help" | "--help" | "-h" => { print_help(); Ok(()) }
        other => Err(format!("unknown command '{other}'. Run `nsc help`.")),
    }
}

fn main() {
    let argv: Vec<String> = std::env::args().skip(1).collect();
    let (cmd, cli) = match parse_args(&argv) {
        Ok(v) => v,
        Err(e) => { eprintln!("error: {e}"); std::process::exit(2); }
    };
    if cli.has("help") && cmd != "help" { print_help(); return; }
    match dispatch(&cmd, &cli) {
        Ok(()) => {}
        Err(e) => { eprintln!("error: {e}"); std::process::exit(1); }
    }
}

#[cfg(test)]
mod tests {
    use super::*;
    /// Live-feature encode -> decode must recover the token stream exactly. Uses the dev fixtures in
    /// artifacts/ (skips on a fresh checkout where the 285 MB artifacts are absent).
    #[test]
    fn roundtrip_bit_identical() {
        for f in ["artifacts/model.nsc", "artifacts/o2.nsc", "artifacts/ref.nsc"] {
            if std::fs::metadata(f).is_err() { eprintln!("roundtrip: {f} missing — skipping"); return; }
        }
        let model = Model::load("artifacts/model.nsc");
        let o2 = O2Table::load("artifacts/o2.nsc");
        let b = std::fs::read("artifacts/ref.nsc").unwrap();
        let mut o = 0usize;
        let t = codec::ru32(&b, &mut o) as usize;
        let _v = codec::ru32(&b, &mut o) as usize;
        let tokens: Vec<usize> = (0..t).map(|_| codec::ri32(&b, &mut o) as usize).collect();
        let (payload, nbits) = codec::encode_tokens(&model, &o2, &tokens, 4);
        let rec = codec::decode_tokens(&model, &o2, tokens[0], tokens.len(), payload, nbits);
        assert_eq!(rec, tokens, "round-trip token mismatch");
    }
}
