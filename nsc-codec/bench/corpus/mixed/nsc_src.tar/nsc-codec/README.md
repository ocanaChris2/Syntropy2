# nsc — neuro-symbolic lossless codec

A pure-Rust (zero third-party crates) **lossless** compressor that runs the Syntropy2
neuro-symbolic predictor in int8 and drives a range coder. It is a bit-exact port of
`int8_codec.py` (see `../RUST_INTEGRATION_BLUEPRINT.md`), packaged as an installable `nsc` command
with a **versioned model registry** so models can be upgraded safely, plus a parallel batch mode.

The Rust side does the heavy per-token work — the int8 GRU + RoPE transformer + gate + fusion, the
classical order-0/1/2 + match feature model, and the range coder. Byte↔token-id conversion is the
one step kept in Python (`tok.py`, needs `tokenizers` + `numpy`).

**Why it is lossless:** the encoder and decoder run the *identical* Rust feature model + int8
forward + quantizer over the *same* token prefix, so they produce identical coder tables and the
round-trip is byte-exact **by construction** — it does not depend on matching PyTorch bit-for-bit
(the Rust forward differs by ~5e-7 due to libm vs PyTorch math; that is fine). A file compressed by
a given model version must be decompressed by that same version — which the registry guarantees
automatically (see [Model upgrading](#model-upgrading)).

```
 bytes ──nsc compress──▶ file.nsc ──nsc decompress──▶ bytes
          (records the model id + fingerprint inside file.nsc)
```

---

## Quick start

```bash
cd nsc-codec
./install.sh                       # build + install `nsc` + seed the registry (~/.nsc)
# ensure ~/.local/bin is on PATH, then:

nsc compress   book.txt  book.nsc  # bytes -> compressed  (uses the default model)
nsc decompress book.nsc  out.txt   # compressed -> bytes  (auto-selects the recorded model)
cmp book.txt out.txt && echo lossless

nsc info   book.nsc                 # model id, tokens, ratio recorded in the file
nsc models                          # installed model versions (* = default)
nsc doctor --verify                 # health check: python, tok.py, model fingerprints
```

A single `nsc compress`/`decompress` wraps tokenization automatically (it shells out to
`python3 tok.py`). For the pure Rust path (no Python), use `compress-ids`/`decompress-ids` on
pre-tokenized `.ids` files.

### Any file, always lossless (raw-stored fallback)

The neural model targets **text/code**. Feeding it already-compressed or binary data (mp4, images,
zip, …) would only *expand* it and could exhaust memory tokenizing hundreds of MB. So `nsc compress`
detects such input and **stores it verbatim** inside the `.nsc` container (`NSCR` format) — the copy
is streamed, so a 600 MB file compresses in a fraction of a second at a few MB of RAM, and
`decompress` reproduces the bytes exactly. The result: `nsc` **never fails and always round-trips**,
on any file. Three more safety nets keep it honest:

- if the neural output would be *larger* than the raw bytes, the raw store is kept instead (ratio is
  never worse than ~1.0);
- if the neural path fails for any reason (e.g. an out-of-memory tokenizer on a huge file), it falls
  back to storing the bytes rather than erroring;
- `--store` forces the raw fallback; `--neural` forces the model even on binary-looking input (kept
  only if it actually wins). `nsc info` shows `NSCR (stored)` for stored files.

---

## Studio — the local dashboard

```bash
nsc studio                 # serves http://127.0.0.1:8765 and opens your browser
nsc studio --port 9000     # pick a port
nsc studio --root results  # file browser opens here (default: current dir, not $HOME)
```

`nsc studio` launches a **self-contained web app** (a std-only HTTP server built into the `nsc`
binary — no extra dependency, no framework, nothing to install) for watching the codec's behaviour
on real files. It is meant for exactly the intermediate-training phase: point it at real documents
and see, live, how the current model performs — then hot-deploy an improved checkpoint and watch
the numbers move.

Three panels:

- **Compress** — browse to any local file, compress it, and see live metrics: ratio, bits-per-byte,
  tokens, encode time, decode speed, and a **byte-exact roundtrip check**. Tick *vs classical* to
  race it against `gzip -9`, `xz -9`, `zstd -19`, and `7z-PPMd` on the same file (bar chart).
  A Decompress/restore box round-trips any `.nsc` back to bytes.
- **Models & Upgrades** — the versioned registry as a table (set default, remove) plus a
  **Deploy an upgrade** form: register a freshly trained export (`model.nsc` + `o2.nsc` +
  `tokenizer.json`) as a new version, optionally making it the default. Safe by construction —
  every `.nsc` records the model + fingerprint that made it, so old files keep decoding.
- **Metrics & History** — every run is persisted (`~/.nsc/studio_history.json`). A density-over-time
  chart, coloured by model version, lets you see a new upgrade pull bits-per-byte down; a
  per-version summary table tracks average bpc, ratio, and lossless rate.

Everything drives the same registry and codec paths as the CLI, so what you see in Studio is what
you get from `nsc compress`.

---

## Install / deploy

```bash
./install.sh                         # PREFIX=~/.local/bin  NSC_HOME=~/.nsc
PREFIX=/usr/local/bin ./install.sh   # system-wide binary
NSC_HOME=/opt/nsc     ./install.sh   # shared registry (export NSC_HOME for clients)
# or:  make install
```

`install.sh` (re-runnable) builds the release binary, installs it as `nsc`, copies the tokenizer
shim to `$NSC_HOME/tok.py`, and imports the current `artifacts/` as the default model `base-v1`.

**Runtime requirements:** `python3` on `PATH` with `tokenizers` and `numpy` installed (for the
tokenizer step only). Override the interpreter with `NSC_PYTHON`, the shim path with `NSC_TOK`.

**Environment:** `NSC_HOME` (registry root, default `~/.nsc`) · `NSC_PYTHON` · `NSC_TOK` ·
`NSC_TOKENIZER` (fallback tokenizer for `tok.py`).

---

## Model upgrading

This is the point of the registry: **you can ship a better model without breaking existing files.**

Each model version lives in its own directory and carries its own weights **and** its own
tokenizer:

```
~/.nsc/
  default                       # id of the default model
  tok.py
  models/
    base-v1/  model.nsc  o2.nsc  tokenizer.json  manifest.json
    base-v2/  ...
```

Every compressed file records the **id + content fingerprint** of the model that produced it, so:

- `nsc decompress` **auto-selects the exact model** the file was made with — even if the default
  has since changed. Old files keep decompressing after an upgrade.
- If the model behind that id has been altered on disk (registry drift), the fingerprint mismatch
  is caught and decompression **refuses** rather than silently corrupting the output.

Upgrade workflow — after training/exporting a new checkpoint:

```bash
# 1. export the artifacts for the new checkpoint (see below)
python3 export_int8.py            # -> artifacts/model.nsc
python3 export_o2.py              # -> artifacts/o2.nsc

# 2. register it as a new version and make it the default for NEW compressions
nsc models add base-v2 \
    --model-nsc artifacts/model.nsc --o2 artifacts/o2.nsc \
    --tokenizer ../results/export/tokenizer.json \
    --tier base --bpc 1.28 --created "$(date +%F)" --default

nsc models                        # base-v2 is now the default (*)
# existing *.nsc files still decompress via base-v1 automatically
```

Registry management: `nsc models list` · `nsc models add <id> …` · `nsc models default <id>` ·
`nsc models remove <id>`.

---

## Scalability (batch, parallel)

Model load (~273 MB) is the dominant fixed cost, so batch mode loads each needed model **once** and
compresses/decompresses many files across CPU cores:

```bash
nsc batch compress   *.txt        --out-dir out  --jobs 8
nsc batch decompress out/*.nsc    --out-dir back --jobs 8
```

`--jobs` defaults to the CPU count. Each file is independent (its own coder state); the loaded
model is shared read-only across worker threads (`std::thread::scope`, still zero-dependency).
For decompression, files referencing different model versions are handled in the same run — each
distinct model is loaded once and reused.

---

## Command reference

| Command | Purpose |
|---|---|
| `nsc compress <in> <out.nsc>` | Compress a file end-to-end (tokenize + code). |
| `nsc decompress <in.nsc> <out>` | Decompress; auto-selects the recorded model. |
| `nsc compress-ids <in.ids> <out.nsc>` | Compress a pre-tokenized `.ids` file (no Python). |
| `nsc decompress-ids <in.nsc> <out.ids>` | Decompress to `.ids` (no Python). |
| `nsc batch <compress\|decompress> <files…>` | Parallel batch; `--jobs`, `--out-dir`. |
| `nsc info <file.nsc>` | Show container header (model id, tokens, bits/token). |
| `nsc models [list\|add\|default\|remove]` | Manage the model registry. |
| `nsc doctor [--verify]` | Check registry, python/tok.py, and (`--verify`) fingerprints. |
| `nsc studio [--port N] [--root DIR]` | Launch the local web dashboard (compress, metrics, model upgrades). `--root` sets where the file browser opens (default: current dir). |
| `nsc selftest` | Developer parity harness (Stages A–E) vs `artifacts/`. |
| `nsc help` / `nsc version` | Usage / version. |

Global flags: `--model <id>` (compress with a non-default model) · `--home <path>` (registry root)
· `--jobs <n>` · `--out-dir <dir>` · `--keep-ids` · `-q/--quiet`.

**Measured** (base-v1, 4 threads): a 10 KB enwik8 slice → 1126 B = **0.90 bits/byte** (content
dependent; long mixed text approaches the model's ~1.29 bits/byte). Forward throughput is
~440 tok/s per core; end-to-end wall-clock also includes a one-time ~1–2 s model load (amortized in
`batch`) and the tokenizer subprocess.

---

## Exporting model artifacts

The registry is seeded from artifacts regenerated from a trained checkpoint
(`../results/export/best.pt`); they are large and not committed:

```bash
python3 export_int8.py   # -> artifacts/model.nsc  (+ artifacts/ref.nsc for tests)
python3 export_o2.py     # -> artifacts/o2.nsc     (FastO2 order-2 table)
```

Optional verification fixtures: `python3 test_vectors/gen.py` (Stage A) and
`python3 dump_intermediates.py` (Stage C).

| File | Size | Required? | Purpose |
|---|---:|---|---|
| `model.nsc` | ~273 MiB | registry | int8 weights + config + `embed`/`order0`/**`order1` (exact f32)** + gate (106 tensors) |
| `o2.nsc` | ~30 MiB | registry | FastO2 order-2 table + `K` + `cap` for the online feature model |
| `tokenizer.json` | ~527 KiB | registry | byte ↔ token-id bijection (per model version) |
| `ref.nsc` / `inter.nsc` / `vec.bin` | — | tests only | Stage A/C/D/E parity fixtures |

`model.nsc` is large because it embeds `order1` as **exact f32** (`V×V×4 B` ≈ 256 MB); the f16
export is lossy and would break the bit-exact coder tables.

---

## Verify

```bash
cd nsc-codec
cargo test --release        # roundtrip_bit_identical (live features, byte-exact)
nsc selftest                # Stages A–E vs Python (run from the crate dir; reads artifacts/)
make doctor                 # registry + fingerprint health
```

`selftest` prints, e.g.:

```
Stage E feature model vs Python: 0/63 positions differ
Stage D Rust roundtrip: 63 tokens, ... ✓ BYTE-EXACT
=> A coder:PASS | B load:OK | E feats:exact | C GRU:diff | C fidelity-vs-python:~5e-7 (fine) | D Rust roundtrip:BYTE-EXACT ✓
```

---

## Formats & internals

- **`.nsc` container v2 (`NSC2`)** — `magic "NSC2" | fmt u16 | id_len u16 | model_id | fingerprint
  u64 | vocab u32 | seg u32 | n_tokens u32 | first_token u32 | n_bits u32 | payload`. The first
  token is raw; tokens `1..` are entropy-coded. Legacy v1 (`NSCZ`, no model binding) is still read.
  Loader: `src/container.rs`.
- **`model.nsc`** — `magic "NSC1" | 9×u32 cfg | eps f32 | n_tensors u32 |` per tensor
  `name_len u16, name, dtype u8 (0=f32,1=i8,2=f64), ndim u8, dims…, data`. Linears store
  `{.code i8 [out,in], .scale f64 [out], .bias f32 [out]}` (per-output-channel int8 via `qrow`).
  Loader: `src/artifacts.rs`.
- **`o2.nsc`** — `magic "NO21" | V u32 | K u32 | cap f32 | n u32 | ctx[i64] | top[i32] | conf[f32]`.
  Loader + online feature model: `src/features.rs`.
- **`.ids`** — `magic "NIDS" | n u32 | n×token-id u32` (shared by `tok.py` and the codec).
- **`manifest.json`** — flat JSON per model: `id, tier, vocab_size, seg_len, d_model, bpc, created,
  fingerprint (FNV-1a-64 over model.nsc+o2.nsc), format, notes`. Loader: `src/registry.rs`.
- **Determinism knobs (must not change):** per-row int8 (`round_ties_even`, clamp `[-128,127]`,
  scale floor `1e-30`), i32 exact accumulation + f64 dequant, `T = 1.0`, `QUANT_BITS = 22`, neural
  window reset every `seg_len` (1024), continuous feature model.

## Source map

| File | Role |
|---|---|
| `src/main.rs` | `nsc` CLI: subcommands, tokenizer bridge, parallel batch, arg parsing |
| `src/registry.rs` | versioned model registry (list/add/default/resolve, fingerprint, manifest) |
| `src/container.rs` | `.nsc` container v2 (model-bound) + legacy reader |
| `src/codec.rs` | shared core: quantizer, `encode_tokens`/`decode_tokens`, `.ids` I/O |
| `src/range_coder.rs` | 32-bit Witten–Neal–Cleary range coder |
| `src/artifacts.rs` | `model.nsc` loader; precomputes per-token order-1 `max`/entropy |
| `src/forward.rs` | int8 forward: GRU×2, RoPE transformer + int8 KV-cache, gate, fusion |
| `src/features.rs` | `o2.nsc` loader + online order-2/match feature model |
| `src/studio.rs` / `src/studio.html` | `nsc studio` — std-only web dashboard (server + embedded UI) |
| `src/selftest.rs` | Stage A–E parity harness |
| `export_int8.py` / `export_o2.py` | export `model.nsc` / `o2.nsc` |
| `tok.py` | byte ↔ token-id shim (`enc`/`dec`, per-model tokenizer) |
| `install.sh` / `Makefile` | build + deploy + registry seeding |
